function toRadians(value) {
    return value * (Math.PI / 180);
}

function haversineMiles(lat1, lon1, lat2, lon2) {
    const earthRadiusMiles = 3958.7613;

    const dLat = toRadians(lat2 - lat1);
    const dLon = toRadians(lon2 - lon1);

    const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRadians(lat1)) *
            Math.cos(toRadians(lat2)) *
            Math.sin(dLon / 2) ** 2;

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return earthRadiusMiles * c;
}

module.exports = {
    haversineMiles
};
