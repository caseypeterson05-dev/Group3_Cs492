# Pizza Pie Parlor - Team Handoff v2.5.0

## Integrated team homepage (Kelly / SteelThistle + Jon's backend)

The team's combined customer-facing homepage is at **`http://127.0.0.1:3000/home/`** after starting the Express server. It includes Kelly's themed homepage and integrates the existing menu, customization, cart, and API functionality from Jon's handoff.

The original **`http://127.0.0.1:3000/team-demo.html`** remains as an independent technical demonstration; neither interface has been removed. Install dependencies with `npm ci`, run `npm test`, then `npm start` from the folder containing `package.json`.

The application is still a capstone prototype: cart state is held in memory, database persistence and real payment checkout are not implemented, and visual end-to-end acceptance testing is still required.

For first-time GitHub setup and safe upload instructions, see **`GITHUB_SUBMISSION_GUIDE.md`**.

**This is an upgrade to the original v2.1.3 backend, not a replacement.**
The Node/Express package version remains **2.2.0**. The v2.5.0 label is
for the documentation-focused team handoff ZIP. All original source files
are retained, and the original detailed README is archived unchanged.

For Notepad, use **README.txt** or **START_HERE.txt**. For clickable local
file navigation, double-click **OPEN_HANDOFF.html**.

## Start the demo (Windows)

Extract the ZIP, open PowerShell in the folder with `package.json`, and run:

```powershell
$env:Path = "C:\Program Files\nodejs;$env:Path"
npm.cmd ci
npm.cmd test
npm.cmd start
```

Then open `http://127.0.0.1:3000/team-demo.html` in a browser on the same
computer. Stop another server on port 3000 first. `localhost` is not a
public preview URL; the HTML must be served by Node to access `/api`.

## Sprint scope

- **7.1:** Working add/view/update/remove/cart customization interface.
- **7.2:** REST cart API and improved input validation, plus automated tests.
- **9.1:** Promo entry is assigned separately. The included promo modal and
  estimated discounted total are demonstrations, not final checkout pricing.

Carts are currently in memory. Checkout and database persistence are not
implemented. The space theme is a changeable reference, not the team's
approved visual design.

## Find the documentation (relative file paths, not broken links)

- `UPGRADE_FROM_v2.1.3.txt`: Original-versus-upgrade differences and merge advice.
- `DESIGN_EDITING_GUIDE.txt`: Exactly where to change colors, copy and layouts.
- `REQUIREMENTS_7_1_7_2.txt`: Sprint scope.
- `DOCUMENT_INDEX.txt`: Source-code map.
- `docs/history/README_BACKEND_v2.1.3.md`: **Unchanged original README**
  with backend rationale and earlier Task 1.2, 6.2, and 9.2 history.
- `docs/history/README_BACKEND_v2.1.3.txt`: Notepad-friendly archived copy.
- `docs/TASK_7_2_CART_API.txt`: API contract guide.
- `docs/TESTING.txt`: Verification guide.

## Safe visual edits

| Change | Active file |
| --- | --- |
| Theme and product cards | `public/cart-demo/css/planet-theme.css` |
| Promo dialog | `public/cart-demo/css/promo-modal.css` |
| Hero, copy and truck SVG | `public/team-demo.html` |
| Cart and promo wording | `public/cart-demo/js/site-content.js` |
| Dynamic card/cart markup | `public/cart-demo/js/view.js` (advanced) |

Business logic is in separate JavaScript and backend modules. Do not change
API services or JavaScript-bound HTML IDs to adjust visual styling.
`public/cart-demo.html` is an alternate older demo and has different CSS.

## Team merge

Do not overwrite an active team repository. Compare the updated code with
any newer changes on the team's branch, integrate selectively, run
`npm.cmd test`, and visually verify the cart and promo behavior. The
historical README is preserved for technical and contribution context.
